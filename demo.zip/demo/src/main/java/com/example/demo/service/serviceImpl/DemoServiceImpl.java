package com.example.demo.service.serviceImpl;

import com.example.demo.service.DemoService;
import com.example.demo.utility.CapabilityExcelDataUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;


@Service
public class DemoServiceImpl implements DemoService {

    @Override
    public void processCapabilityDataFromExcel(MultipartFile file) throws IOException, InvalidFormatException {
        CapabilityExcelDataUtil capabilityExcelDataUtil = new CapabilityExcelDataUtil();

            capabilityExcelDataUtil.readCapabilitiesDataFromExcel(file);
    }
}
