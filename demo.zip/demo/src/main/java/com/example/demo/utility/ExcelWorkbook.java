package com.example.demo.utility;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;



public class ExcelWorkbook {
	
	private final static Logger log = LoggerFactory.getLogger(ExcelWorkbook.class);
	
	public XSSFWorkbook getWorkbook(final MultipartFile file) throws IOException, InvalidFormatException {
		XSSFWorkbook workbook = null;
		
		log.info("filename - "+file.getOriginalFilename()+"\n"+file.getName());

		if (file.getOriginalFilename().endsWith("xlsx")) {
			workbook = new XSSFWorkbook(ConvertMultipartFileToFile.convert(file));
		}
		/*
		 * else if (excelFilePath.endsWith("xls")) { workbook = new
		 * HSSFWorkbook(fileStream); }
		 */
		else {
			throw new IllegalArgumentException("The specified file is not an Excel file. It should end with .xlsx.");
		}

		return workbook;
	}
	public void deleteWorkbook() {
		ConvertMultipartFileToFile.delete();
	}

}
