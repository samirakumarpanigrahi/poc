package com.example.demo.service;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface DemoService {
    void processCapabilityDataFromExcel(MultipartFile file) throws IOException, InvalidFormatException;
}
