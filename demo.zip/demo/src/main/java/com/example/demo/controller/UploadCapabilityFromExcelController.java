package com.example.demo.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.example.demo.service.DemoService;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;



@RestController
@CrossOrigin
@RequestMapping("/upload/excel/capability")
public class UploadCapabilityFromExcelController {

//	private static final Logger log = LoggerFactory.getLogger(UploadCapabilityFromExcelController.class);

	@Autowired
	private DemoService capabilityExcelService;



	@PostMapping("/save")
	public ResponseEntity<Map<String, Object>> uploadCapabilitiesByExcel(@RequestParam("file") MultipartFile file
			) {


		Map<String, Object> response = new HashMap<>();


		try {
			this.capabilityExcelService.processCapabilityDataFromExcel(file);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		}

		response.put("success", true);
				response.put("status", HttpStatus.OK);
//				response.put("body", this.capabilityExcelService.saveCapabilitiesFromExcel());
				response.put("error", false);
				System.out.println(response+"-----------------------------------------");
				return ResponseEntity.status(HttpStatus.OK)
						.header("status", String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR)).body(response);


	}

}
