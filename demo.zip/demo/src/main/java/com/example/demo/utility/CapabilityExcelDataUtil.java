package com.example.demo.utility;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Iterator;

public class CapabilityExcelDataUtil {

    private final ExcelWorkbook excelWorkBook = new ExcelWorkbook();
//	private List<Capability> capabilities;

//	private static final Logger log = LoggerFactory.getLogger(CapabilityExcelDataUtil.class);

//	public List<Capability> getCapabilityDetails() {
//		return capabilities;
//	}

//	public void setCapabilityDetails(List<Capability> capabilities) {
//		this.capabilities = capabilities;
//	}

    public void readCapabilitiesDataFromExcel(MultipartFile uploadFile) throws IOException, InvalidFormatException {


        XSSFWorkbook workbook = this.excelWorkBook.getWorkbook(uploadFile);
        XSSFSheet spreadsheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = spreadsheet.iterator();
        while (rowIterator.hasNext()) {
            Row nextRow = rowIterator.next();
            if (nextRow.getRowNum() > 0) {
                Iterator<Cell> cellIterator = nextRow.cellIterator();

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (cell.getColumnIndex() == 0) {
                        if (cell.getCellTypeEnum() == CellType.STRING) {
                            System.out.println(cell.getStringCellValue());
                        }
                    } else if (cell.getColumnIndex() == 1) {
                        if (cell.getCellTypeEnum() == CellType.STRING) {
                            System.out.println(cell.getStringCellValue());
                        }
                    }
//					else if (cell.getColumnIndex() == 2) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							capabilityDetails.setIntroduction((cell.getStringCellValue()));
//						}
//					} else if (cell.getColumnIndex() == 3) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							capabilityDetails.setVideoLink((cell.getStringCellValue()));
//						}
//					} else if (cell.getColumnIndex() == 4) {
//						if (cell.getCellTypeEnum() == CellType.BOOLEAN) {
//							capabilityDetails.setMandatory(cell.getBooleanCellValue());
//						}
//					} else if (cell.getColumnIndex() == 5) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							capabilityDetails.setCreatedBy(cell.getStringCellValue());
//						}
//
//					} else if (cell.getColumnIndex() == 6) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							try {
//								System.out.println("check");
//								System.out.println(cell.getStringCellValue());
//								String observationsFromExcel = cell.getStringCellValue();
//								for (int i = 0; i < observationsFromExcel.split(";\\$").length; i++) {
//
//									observation = new Observation();
//									observation.setDescription(observationsFromExcel.split(";\\$")[i]);
//									observation.setMandatory(true);
//									observations.add(observation);
//								}
//								observations.forEach(obj -> System.out.println(obj));
//								System.out.println("check1");
//							} catch (ArrayIndexOutOfBoundsException e) {
//								throw new IOException("Wrong Format in KO Observation line " + nextRow.getRowNum()
//										+ " column " + cell.getColumnIndex() + " ,the format is 'Topic1;$Topic2'");
//							}
//
//						}
//
//					} else if (cell.getColumnIndex() == 7) {
//						System.out.println("five");
//						try {
//							if (cell.getCellTypeEnum() == CellType.STRING) {
//
//								String observationsFromExcel = cell.getStringCellValue();
//
//								for (int i = 0; i < observationsFromExcel.split(";\\$").length; i++) {
//									observation = new Observation();
//									observation.setDescription(observationsFromExcel.split(";\\$")[i]);
//									observation.setMandatory(false);
//									observations.add(observation);
//								}
//							}
//						} catch (ArrayIndexOutOfBoundsException e) {
//							throw new IOException("Wrong Format in Non Ko Observation line " + nextRow.getRowNum()
//									+ " column " + cell.getColumnIndex() + " ,the format is 'Topic1;$Topic2'");
//						}
//
//						System.out.println("check2");
//
//					} else if (cell.getColumnIndex() == 8) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							try {
//								String referencesFromExcel = cell.getStringCellValue();
//								LinkedHashSet<Reference> references = new LinkedHashSet<>();
//								Reference reference;
//								for (int i = 0; i < referencesFromExcel.split(";\\$").length; i++) {
//									String referenceFromExcel = referencesFromExcel.split(";\\$")[i];
//									reference = new Reference();
//									reference.setLink(referenceFromExcel.split("\\$\\$")[1]);
//									reference.setDescription(referenceFromExcel.split("\\$\\$")[0]);
//
//									references.add(reference);
//								}
//								capabilityDetails.setReferences(references);
//							} catch (ArrayIndexOutOfBoundsException e) {
//								throw new IOException("Wrong Format in References line " + nextRow.getRowNum()
//										+ " column " + cell.getColumnIndex() + " ,the format is 'Topic Name$$link"
//										+ ";$" + "Topic Name $$link" + ";$'");
//							} catch (Exception e) {
//								throw new IOException("Wrong Format in References line " + nextRow.getRowNum()
//								+ " column " + cell.getColumnIndex() + " ,the format is 'Topic Name$$link"
//								+ ";$" + "Topic Name $$link" + ";$'");
//					}
//							// using pattern matching to select various data in the string
//
//						}
//
//					}
//					/*
//					 * else if (cell.getColumnIndex() == 9) { System.out.println("seven"); if
//					 * (cell.getCellTypeEnum() == CellType.STRING) {
//					 *
//					 * String capabilityFromExcel = cell.getStringCellValue();
//					 *
//					 * for (int i = 0; i < capabilityFromExcel.split(";\\$").length; i++) {
//					 * capabilityScenarios.add(capabilityFromExcel.split(";\\$")[i]); } }
//					 * System.out.println("check2"); capabilityScenarios.forEach(obj ->
//					 * System.out.println(obj));
//					 *
//					 * }
//					 *
//					 */
//
//					else if (cell.getColumnIndex() == 9) {
//
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							try {
//								String assignmentsFromExcel = cell.getStringCellValue();
//
//								assignments = new LinkedHashSet<>();
//								System.out.println("comming here");
//								for (int i = 0; i < assignmentsFromExcel.split(";\\$").length; i++) {
//									String assignmentFromExcel = assignmentsFromExcel.split(";\\$")[i];
//									assignment = new Assignment();
//									assignment.setId(new ObjectId().toString());
//
//									assignment.setLink(assignmentFromExcel.split("\\$\\$")[1]);
//									assignment.setTopic(assignmentFromExcel.split("\\$\\$")[0]);
//									assignment.setIsDone(false);
//									assignments.add(assignment);
//								}
//							} catch (Exception e) {
//								throw new IOException("Wrong Format in Assignment line " + nextRow.getRowNum()
//										+ " column " + cell.getColumnIndex() + " ,the format is 'Topic Name$$link"
//										+ ";$" + "Topic Name $$link" + ";$'");
//							}
//
//						}
//
//					} else if (cell.getColumnIndex() == 10) {
//						if (assignments != null) {
//							try {
//								System.out.println(assignments);
//								String descriptionFromExcel = cell.getStringCellValue();
//								Iterator<Assignment> itr = assignments.iterator();
//								System.out.println(itr);
//								for (int i = 0; i < descriptionFromExcel.split(";\\$").length; i++) {
//
//									if (itr.hasNext()) {
//										Assignment a1 = itr.next();
//										System.out.println(a1);
//										a1.setDescription(descriptionFromExcel.split(";\\$")[i]);
//									}
//								}
//								capabilityDetails.setAssignments(assignments);
//							} catch (Exception e) {
//								throw new IOException("Wrong Format in Assignment Description line "
//										+ nextRow.getRowNum() + " column " + cell.getColumnIndex()
//										+ " ,the format is '1. Topic1;$" + "2. Topic2'");
//							}
//
//						}
//					} else if (cell.getColumnIndex() == 11) {
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							try {
//								Skill skill;
//								LinkedHashSet<Skill> skills = new LinkedHashSet<>();
//								String skillsFromExcel = cell.getStringCellValue();
//
//								for (int i = 0; i < skillsFromExcel.split(";\\$").length; i++) {
//									skill = new Skill();
//									skill.setSkillDescription(skillsFromExcel.split(";\\$")[i]);
//									skills.add(skill);
//									/*
//									 * observation.setDescription(observationsFromExcel.split(";\\$")[i]);
//									 * observation.setMandatory(false); observations.add(observation);
//									 */
//								}
//								capabilityDetails.setSkills(skills);
//							} catch (Exception e) {
//								throw new IOException("Wrong Format in Skill Description line " + nextRow.getRowNum()
//										+ " column " + cell.getColumnIndex() + " ,the format is 'Topic1;$" + "Topic2'");
//							}
//
//						}
//						System.out.println("check2");
//
//					} else if (cell.getColumnIndex() == 12) {
//						System.out.println("five");
//						if (cell.getCellTypeEnum() == CellType.STRING) {
//							try {
//								SubSkill subSkill;
//								LinkedHashSet<SubSkill> subSkills = new LinkedHashSet<>();
//								String subSkillsFromExcel = cell.getStringCellValue();
//
//								for (int i = 0; i < subSkillsFromExcel.split(";\\$").length; i++) {
//									subSkill = new SubSkill();
//									subSkill.setSubSkillDescription(subSkillsFromExcel.split(";\\$")[i]);
//									subSkills.add(subSkill);
//
//								}
//								capabilityDetails.setSubSkills(subSkills);
//							} catch (Exception e) {
//								throw new IOException("Wrong Format in SubSkill Description line " + nextRow.getRowNum()
//										+ " column " + cell.getColumnIndex() + " ,the format is 'Topic1;$" + "Topic2'");
//							}
//
//						}
//						System.out.println("check2");
//
//					}

                }

//				log.info("Details of capabilities - " + capabilityDetails);
//				capabilityDetails.setObservation(observations);
//				capabilityDetailsData.add(capabilityDetails);
//				capabilityDetails.setCapabilityScenarioDescription(capabilityScenarios);
//				setCapabilityDetails(capabilityDetailsData);
            }

        }

        workbook.removeSheetAt(0);
        workbook.close();
//		log.info("Deleting temporarily created workbook");
        this.excelWorkBook.deleteWorkbook();

//		log.info("Finished reading data from excel. Number of records  - " + this.getCapabilityDetails().size());
//		System.out.println(this.getCapabilityDetails().get(0));

    }

}
