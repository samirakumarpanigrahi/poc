package com.example.demo.utility;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;


public class ConvertMultipartFileToFile {
	
	private static final Logger logger = LoggerFactory.getLogger(ConvertMultipartFileToFile.class);
	public static File convFile=null;
	
	public static File convert(MultipartFile file) throws IOException {
	    logger.info("converting  multipart file to file started");
	    logger.info("multipart file name- "+file.getOriginalFilename());
		
		convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile();
	    FileOutputStream fos = new FileOutputStream(convFile);
	    fos.write(file.getBytes());
	    fos.close();
	    logger.info("successfully converted multipart file to file");
	    
	    return convFile;
	}
	
	public static void delete() {
		convFile.delete();		
	}

}
